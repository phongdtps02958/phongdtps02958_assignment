﻿<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body bgcolor="#66FFFF">
<?php
echo '<center><h1>HƯỚNG DẪN MUA HÀNG</h2></center>';
echo '<h4>Bước 1: Kích vào chữ: Mua sách này để chọn mua mặt hàng</br><br>';
echo 'Bước 2: Nhập số lượng mỗi mặt hàng cần mua, rồi nhấn nút cập nhật</br></br>';
echo 'Bước 3: Tìm kiếm theo tên sách hoặc tác giả rồi mua hàng</br></br>';
echo 'Bước 4: Nhấn thanh toán để xác nhận hóa đơn mua hàng. Hóa đơn sẽ được lưu. Hàng sẽ được chuyển đến địa chỉ của bạn trong tài khoản đăng ký thành viên';
echo '<p align=center><b><A Href="index.php">Về trang chủ</A></b></p>';
?>
</body>